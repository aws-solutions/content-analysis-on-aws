# Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

import json
import boto3
import os
import uuid
import time

# Package for implementing operations for the AWS Media Analysis Solution
