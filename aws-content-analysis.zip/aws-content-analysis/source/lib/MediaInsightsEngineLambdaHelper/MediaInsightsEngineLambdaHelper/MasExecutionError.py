class MasExecutionError(Exception):
    pass
