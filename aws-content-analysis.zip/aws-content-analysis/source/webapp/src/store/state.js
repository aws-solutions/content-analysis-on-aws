export default {
  player: null,
  markers: [],
  display_asset_id: '',
  chart_tuples: [],
  selected_label: '',
  execution_history: [],
}
