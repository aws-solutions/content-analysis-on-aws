<template>
  <p>Uh oh, we were unable to retrieve all the selected data in time :( </p>
</template>

<script>
export default {
  name: 'ComponentLoadingError',
  data () {
    return {
    }
  }
}
</script>

<style>

</style>