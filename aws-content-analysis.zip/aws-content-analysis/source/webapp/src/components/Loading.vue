<template>
  <div>
    <b-container>
      <b-spinner label="Loading..." />
    </b-container>
  </div>
</template>

<script>

export default {
    name: "Loading"
}
</script>

<style>
</style>
